Species <- c(
   S_Scaup = "Scaup",
   S_longtaile = "Long-tailed Duck",
   S_Commonsco = "Common Scoter",
   S_Velvetsco = "Velvet Scoter",
   S_Slavonian = "Slavonian Grebe",
   S_Redbreast = "Red-breasted Merganser",
   S_Goldeneye = "Goldeneye",
   S_Eider = "Eider",
   S_Redthroat = "Red-throated Diver",
   S_Greatnort = "Great Northern Diver",      
   S_Shag = "Shag"
   )
